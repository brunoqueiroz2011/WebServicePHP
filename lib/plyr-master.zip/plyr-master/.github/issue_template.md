<!--- 
Please use this issue template as it makes replicating and fixing the issue easier! 
--->

- [ ] Issue does not already exist
- [ ] Issue observed on https://plyr.io

### Expected behaviour 

### Actual behaviour

### Environment

- Browser:
- Version:  
- Operating System:
- Version: 

Players affected:
- [ ] HTML5 Video
- [ ] HTML5 Audio
- [ ] YouTube
- [ ] Vimeo

### Steps to reproduce 
- 

### Relevant links
